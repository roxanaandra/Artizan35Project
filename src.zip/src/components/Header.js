import untitled from '../assets/images/Untitled.png';
import React from 'react';

const Header = () => {
  return (
    <>
    <header className='header_section'>
        
      <nav>
        <ul className="menu">
        <li><a href="/">Home</a></li>
        <li><a href="menu.js">Menu</a></li>
        <li><a href="contact.js">Contact</a></li>
        </ul>
      </nav>
    </header>
    </>
  );
}

export default Header;
